# 15619_Project
15619 cloud computing team project


/backend	load data to HBase by java
/etl		include two map & reducer files for q3 & q4
/frontend	/HBase	include front end of HBase from q1~q4
		/MySQL	include front end of MySQL from q1~q4
Oak_Phase2Checkpointreport	The file is the report of Phase 2 




